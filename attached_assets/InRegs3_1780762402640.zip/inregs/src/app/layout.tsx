import type { Metadata } from 'next';
import { Share_Tech_Mono, Barlow_Condensed } from 'next/font/google';
import './globals.css';

const shareTechMono = Share_Tech_Mono({
  weight: '400',
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

const barlowCondensed = Barlow_Condensed({
  weight: ['400', '600', '700'],
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'InRegs — Know Where You Stand',
  description:
    'Marine Corps height, weight, and body composition calculator. Know where you stand before weigh-in.',
  keywords: ['USMC', 'Marine Corps', 'height weight', 'body fat', 'PFT', 'CFT', 'MCO 6100'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${shareTechMono.variable} ${barlowCondensed.variable}`}>
      <body className="bg-[#0a0f0d] text-white antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
