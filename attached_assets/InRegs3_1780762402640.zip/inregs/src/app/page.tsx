import Link from 'next/link';
import Header from '@/components/Header';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#0a0f0d] grid-bg relative overflow-hidden">
      <Header />

      {/* Decorative corner accent */}
      <div className="absolute top-20 right-0 w-32 h-32 border-l border-b border-[#4ade80]/10" />
      <div className="absolute bottom-20 left-0 w-24 h-24 border-r border-t border-[#4ade80]/10" />

      {/* Hero */}
      <main className="max-w-lg mx-auto px-4 pt-16 pb-24 flex flex-col min-h-[calc(100vh-57px)]">

        {/* Status indicator */}
        <div className="animate-fade-up flex items-center gap-2 mb-12">
          <span className="w-2 h-2 rounded-full bg-[#4ade80] pulse-dot" />
          <span className="text-xs font-mono text-[#4ade80]/60 tracking-[0.25em] uppercase">
            System Online
          </span>
        </div>

        {/* Main headline */}
        <div className="flex-1 flex flex-col justify-center">
          <div className="animate-fade-up-delay-1 mb-2">
            <span className="text-xs font-mono tracking-[0.4em] text-[#4ade80]/50 uppercase">
              USMC Body Composition
            </span>
          </div>

          <h1 className="animate-fade-up-delay-1 font-mono font-bold text-7xl sm:text-8xl leading-none tracking-tight mb-2">
            IN<br />
            <span className="text-[#4ade80] glow-text">REGS</span>
          </h1>

          <div className="animate-fade-up-delay-2 h-px w-16 bg-[#4ade80]/40 my-6" />

          <p className="animate-fade-up-delay-2 text-[#a3c4a8] font-mono text-base sm:text-lg leading-relaxed mb-2">
            Know where you stand<br />
            <span className="text-white font-bold">before weigh-in.</span>
          </p>

          <p className="animate-fade-up-delay-3 text-[#2d4a35] font-mono text-xs leading-relaxed mt-2 max-w-xs">
            Check your height/weight and body composition against
            Marine Corps standards. No login. No BS.
          </p>
        </div>

        {/* CTA Buttons */}
        <div className="animate-fade-up-delay-4 space-y-3 mt-12">
          <Link
            href="/calculator"
            className="block w-full bg-[#4ade80] text-[#0a0f0d] font-mono font-bold text-base tracking-widest uppercase text-center py-4 hover:bg-[#22c55e] active:scale-[0.98] transition-all"
          >
            Check My Regs →
          </Link>

          <Link
            href="#learn-more"
            className="block w-full border border-[#1e3a24] text-[#4ade80]/60 font-mono text-sm tracking-widest uppercase text-center py-3 hover:border-[#4ade80]/40 hover:text-[#4ade80] transition-colors"
          >
            Learn More
          </Link>
        </div>

        {/* Disclaimer */}
        <p className="mt-8 text-center text-[10px] font-mono text-[#2d4a35] tracking-wider leading-relaxed">
          Results are estimates only. Always verify against current USMC guidance.
        </p>
      </main>

      {/* Learn More Section */}
      <section
        id="learn-more"
        className="max-w-lg mx-auto px-4 pb-24 space-y-6"
      >
        <div className="flex items-center gap-3">
          <div className="h-px flex-1 bg-[#1e3a24]" />
          <span className="text-[10px] font-mono tracking-[0.3em] text-[#4ade80]/50 uppercase">
            How It Works
          </span>
          <div className="h-px flex-1 bg-[#1e3a24]" />
        </div>

        {[
          {
            num: '01',
            title: 'Enter Your Stats',
            body: 'Input your sex, age, height, weight, and body measurements. Add your PFT and CFT scores.',
          },
          {
            num: '02',
            title: 'Get Instant Results',
            body: 'See your estimated body fat percentage calculated via the DoD tape method used in official USMC weigh-ins.',
          },
          {
            num: '03',
            title: 'Know Your Status',
            body: 'Receive a clear pass/fail determination with your risk level: In Regs, Watch Zone, or Out of Regs.',
          },
        ].map((item) => (
          <div
            key={item.num}
            className="bg-[#111a14] border border-[#1e3a24] p-5 corner-marks"
          >
            <div className="flex items-start gap-4">
              <span className="text-2xl font-mono font-bold text-[#4ade80]/20 shrink-0 leading-none">
                {item.num}
              </span>
              <div>
                <h3 className="font-mono font-bold text-white text-sm tracking-wide mb-1">
                  {item.title}
                </h3>
                <p className="text-xs font-mono text-[#a3c4a8]/60 leading-relaxed">
                  {item.body}
                </p>
              </div>
            </div>
          </div>
        ))}

        <div className="bg-yellow-500/5 border border-yellow-500/15 p-4">
          <p className="text-[10px] font-mono text-yellow-400/50 leading-relaxed">
            ⚠ Results are estimates only and do not constitute official USMC body
            composition assessments. Always verify against current MCO 6100.13A
            and your unit&apos;s official weigh-in procedures. This tool is not a
            substitute for an official weigh-in.
          </p>
        </div>

        <Link
          href="/calculator"
          className="block w-full bg-[#4ade80] text-[#0a0f0d] font-mono font-bold text-base tracking-widest uppercase text-center py-4 hover:bg-[#22c55e] active:scale-[0.98] transition-all"
        >
          Start Assessment →
        </Link>
      </section>
    </div>
  );
}
