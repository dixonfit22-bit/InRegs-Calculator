import Header from '@/components/Header';
import CalculatorForm from '@/components/CalculatorForm';

export const metadata = {
  title: 'Calculator — InRegs',
  description: 'Calculate your USMC height/weight and body composition status.',
};

export default function CalculatorPage() {
  return (
    <div className="min-h-screen bg-[#0a0f0d]">
      <Header />

      <main className="max-w-lg mx-auto px-4 pt-8 pb-24">

        {/* Page Header */}
        <div className="mb-8">
          <span className="text-[10px] font-mono tracking-[0.4em] text-[#4ade80]/50 uppercase">
            Body Composition
          </span>
          <h1 className="font-mono font-bold text-3xl text-white mt-1 tracking-tight">
            Assessment Calculator
          </h1>
          <p className="text-xs font-mono text-[#a3c4a8]/50 mt-2 leading-relaxed">
            Enter your measurements to estimate your status against USMC standards.
            Results are estimates — verify against current MCO 6100.13A.
          </p>
        </div>

        {/* Form + Results */}
        <CalculatorForm />
      </main>
    </div>
  );
}
