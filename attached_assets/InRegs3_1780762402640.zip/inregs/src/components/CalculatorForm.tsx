'use client';

import { useState } from 'react';
import InputField from './InputField';
import SelectField from './SelectField';
import ResultSection from './ResultSection';
import { validateInputs, ValidationErrors, FormData } from '@/lib/validation';
import { calculateRegStatus, MarineInput, RegResult, Sex } from '@/lib/marineStandards';

const initialForm: FormData = {
  sex: '',
  age: '',
  heightInches: '',
  weightLbs: '',
  neckInches: '',
  waistInches: '',
  hipInches: '',
  pftScore: '',
  cftScore: '',
};

export default function CalculatorForm() {
  const [form, setForm] = useState<FormData>(initialForm);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [result, setResult] = useState<RegResult | null>(null);

  const isFemale = form.sex === 'female';

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof ValidationErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
    // Clear hip error if sex changes away from female
    if (name === 'sex' && value !== 'female') {
      setErrors((prev) => ({ ...prev, hipInches: undefined }));
    }
  };

  const handleSubmit = () => {
    const validationErrors = validateInputs(form);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      const firstErrorField = document.querySelector('[data-error="true"]');
      firstErrorField?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    const input: MarineInput = {
      sex: form.sex as Sex,
      age: Number(form.age),
      heightInches: Number(form.heightInches),
      weightLbs: Number(form.weightLbs),
      neckInches: Number(form.neckInches),
      waistInches: Number(form.waistInches),
      hipInches: isFemale && form.hipInches ? Number(form.hipInches) : undefined,
      pftScore: Number(form.pftScore),
      cftScore: Number(form.cftScore),
    };

    const calcResult = calculateRegStatus(input);
    setResult(calcResult);

    setTimeout(() => {
      document.getElementById('results')?.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }, 100);
  };

  const handleReset = () => {
    setForm(initialForm);
    setErrors({});
    setResult(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div>
      {/* ── FORM ── */}
      <div className="space-y-6">

        {/* Personal Info */}
        <div>
          <SectionDivider label="Personal Info" />
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2" data-error={!!errors.sex}>
              <SelectField
                label="Sex"
                name="sex"
                value={form.sex}
                onChange={handleChange}
                options={[
                  { value: 'male', label: 'Male' },
                  { value: 'female', label: 'Female' },
                ]}
                error={errors.sex}
              />
            </div>
            <div data-error={!!errors.age}>
              <InputField
                label="Age"
                name="age"
                placeholder="22"
                value={form.age}
                onChange={handleChange}
                error={errors.age}
                min={17}
                max={65}
              />
            </div>
            <div data-error={!!errors.heightInches}>
              <InputField
                label="Height"
                name="heightInches"
                placeholder="70"
                value={form.heightInches}
                onChange={handleChange}
                error={errors.heightInches}
                suffix="in"
                min={50}
                max={90}
              />
            </div>
          </div>
        </div>

        {/* Body Measurements */}
        <div>
          <SectionDivider label="Body Measurements" />
          <div className="grid grid-cols-2 gap-3">
            <div data-error={!!errors.weightLbs}>
              <InputField
                label="Weight"
                name="weightLbs"
                placeholder="185"
                value={form.weightLbs}
                onChange={handleChange}
                error={errors.weightLbs}
                suffix="lbs"
                min={80}
                max={350}
              />
            </div>
            <div data-error={!!errors.neckInches}>
              <InputField
                label="Neck"
                name="neckInches"
                placeholder="15.5"
                value={form.neckInches}
                onChange={handleChange}
                error={errors.neckInches}
                suffix="in"
                step={0.5}
                min={8}
                max={30}
              />
            </div>
            <div className="col-span-2" data-error={!!errors.waistInches}>
              <InputField
                label="Waist (at navel)"
                name="waistInches"
                placeholder="32.5"
                value={form.waistInches}
                onChange={handleChange}
                error={errors.waistInches}
                suffix="in"
                step={0.5}
                min={20}
                max={70}
              />
            </div>

            {/* Hip — female only */}
            {isFemale && (
              <div className="col-span-2" data-error={!!errors.hipInches}>
                <InputField
                  label="Hip (widest point)"
                  name="hipInches"
                  placeholder="38.0"
                  value={form.hipInches}
                  onChange={handleChange}
                  error={errors.hipInches}
                  suffix="in"
                  step={0.5}
                  min={20}
                  max={80}
                />
                <p className="text-[10px] font-mono text-[#4ade80]/30 mt-1">
                  Required for female tape method (DoD formula)
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Fitness Scores */}
        <div>
          <SectionDivider label="Fitness Scores" />
          <div className="grid grid-cols-2 gap-3">
            <div data-error={!!errors.pftScore}>
              <InputField
                label="PFT Score"
                name="pftScore"
                placeholder="240"
                value={form.pftScore}
                onChange={handleChange}
                error={errors.pftScore}
                min={0}
                max={300}
              />
            </div>
            <div data-error={!!errors.cftScore}>
              <InputField
                label="CFT Score"
                name="cftScore"
                placeholder="270"
                value={form.cftScore}
                onChange={handleChange}
                error={errors.cftScore}
                min={0}
                max={300}
              />
            </div>
          </div>
        </div>

        <button
          onClick={handleSubmit}
          className="w-full bg-[#4ade80] text-[#0a0f0d] font-mono font-bold text-base tracking-widest uppercase py-4 hover:bg-[#22c55e] active:scale-[0.98] transition-all"
        >
          Run Assessment →
        </button>

        <p className="text-center text-[10px] font-mono text-[#2d4a35] leading-relaxed">
          Results are estimates only. Verify all results against current MCO 6100.13A
          and your unit&apos;s official weigh-in procedures.
        </p>
      </div>

      {/* ── RESULTS ── */}
      {result && (
        <ResultSection
          result={result}
          pftScore={Number(form.pftScore)}
          cftScore={Number(form.cftScore)}
          onReset={handleReset}
        />
      )}
    </div>
  );
}

function SectionDivider({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <div className="h-px flex-1 bg-[#1e3a24]" />
      <span className="text-[10px] font-mono tracking-[0.3em] text-[#4ade80]/50 uppercase">
        {label}
      </span>
      <div className="h-px flex-1 bg-[#1e3a24]" />
    </div>
  );
}
