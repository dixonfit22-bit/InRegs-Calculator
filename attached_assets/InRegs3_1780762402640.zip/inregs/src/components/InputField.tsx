'use client';

interface InputFieldProps {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  suffix?: string;
  min?: number;
  max?: number;
  step?: number;
}

export default function InputField({
  label,
  name,
  type = 'number',
  placeholder,
  value,
  onChange,
  error,
  suffix,
  min,
  max,
  step,
}: InputFieldProps) {
  return (
    <div className="flex flex-col gap-1">
      <label
        htmlFor={name}
        className="text-xs font-mono tracking-widest text-[#4ade80]/80 uppercase"
      >
        {label}
      </label>
      <div className="relative">
        <input
          id={name}
          name={name}
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          min={min}
          max={max}
          step={step}
          className={`w-full bg-[#0a0f0d] border ${
            error ? 'border-red-500' : 'border-[#1e3a24]'
          } text-white font-mono text-base px-4 py-3 focus:outline-none focus:border-[#4ade80] transition-colors placeholder-[#2d4a35] ${
            suffix ? 'pr-14' : ''
          }`}
        />
        {suffix && (
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-mono text-[#4ade80]/50 pointer-events-none">
            {suffix}
          </span>
        )}
      </div>
      {error && (
        <p className="text-red-400 text-xs font-mono mt-0.5">⚠ {error}</p>
      )}
    </div>
  );
}
