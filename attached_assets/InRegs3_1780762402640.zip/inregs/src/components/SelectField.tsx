'use client';

interface SelectOption {
  value: string;
  label: string;
}

interface SelectFieldProps {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: SelectOption[];
  error?: string;
}

export default function SelectField({
  label,
  name,
  value,
  onChange,
  options,
  error,
}: SelectFieldProps) {
  return (
    <div className="flex flex-col gap-1">
      <label
        htmlFor={name}
        className="text-xs font-mono tracking-widest text-[#4ade80]/80 uppercase"
      >
        {label}
      </label>
      <select
        id={name}
        name={name}
        value={value}
        onChange={onChange}
        className={`w-full bg-[#0a0f0d] border ${
          error ? 'border-red-500' : 'border-[#1e3a24]'
        } text-white font-mono text-base px-4 py-3 focus:outline-none focus:border-[#4ade80] transition-colors appearance-none cursor-pointer`}
      >
        <option value="" disabled className="text-[#2d4a35]">
          Select…
        </option>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-[#0a0f0d]">
            {opt.label}
          </option>
        ))}
      </select>
      {error && (
        <p className="text-red-400 text-xs font-mono mt-0.5">⚠ {error}</p>
      )}
    </div>
  );
}
