'use client';

import Link from 'next/link';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-[#0a0f0d]/90 backdrop-blur-md border-b border-[#1e3a24]">
      <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          {/* Tactical emblem */}
          <div className="w-8 h-8 border-2 border-[#4ade80] rotate-45 flex items-center justify-center group-hover:bg-[#4ade80]/10 transition-colors">
            <span className="text-[#4ade80] font-mono text-xs font-bold -rotate-45">IR</span>
          </div>
          <span className="text-white font-mono font-bold tracking-[0.2em] text-lg">
            IN<span className="text-[#4ade80]">REGS</span>
          </span>
        </Link>
        <Link
          href="/calculator"
          className="text-xs font-mono tracking-widest text-[#4ade80] border border-[#4ade80]/40 px-3 py-1.5 hover:bg-[#4ade80]/10 transition-colors"
        >
          CALCULATE
        </Link>
      </div>
    </header>
  );
}
