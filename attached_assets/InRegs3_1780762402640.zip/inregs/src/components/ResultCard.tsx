'use client';

interface ResultCardProps {
  label: string;
  value: string | number;
  unit?: string;
  accent?: 'green' | 'yellow' | 'red' | 'neutral';
  large?: boolean;
}

const accentStyles = {
  green: 'border-[#4ade80]/40 text-[#4ade80]',
  yellow: 'border-yellow-500/40 text-yellow-400',
  red: 'border-red-500/40 text-red-400',
  neutral: 'border-[#1e3a24] text-white',
};

export default function ResultCard({
  label,
  value,
  unit,
  accent = 'neutral',
  large = false,
}: ResultCardProps) {
  return (
    <div className={`bg-[#0a0f0d] border ${accentStyles[accent].split(' ')[0]} p-4 flex flex-col gap-1`}>
      <span className="text-xs font-mono tracking-widest text-[#4ade80]/60 uppercase">
        {label}
      </span>
      <div className="flex items-baseline gap-1.5">
        <span
          className={`font-mono font-bold ${large ? 'text-3xl' : 'text-xl'} ${
            accentStyles[accent].split(' ')[1]
          }`}
        >
          {value}
        </span>
        {unit && (
          <span className="text-xs font-mono text-[#4ade80]/40">{unit}</span>
        )}
      </div>
    </div>
  );
}
