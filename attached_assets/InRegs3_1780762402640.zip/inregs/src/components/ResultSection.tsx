'use client';

import ResultCard from './ResultCard';
import { RegResult } from '@/lib/marineStandards';

interface ResultSectionProps {
  result: RegResult;
  pftScore: number;
  cftScore: number;
  onReset: () => void;
}

type Accent = 'green' | 'yellow' | 'red' | 'neutral';

function getRiskAccent(riskLevel: RegResult['riskLevel']): Accent {
  if (riskLevel === 'In Regs') return 'green';
  if (riskLevel === 'Watch Zone') return 'yellow';
  return 'red';
}

function getRiskBanner(riskLevel: RegResult['riskLevel']) {
  const configs = {
    'In Regs': {
      bg: 'bg-[#4ade80]/10 border-[#4ade80]/30',
      text: 'text-[#4ade80]',
      icon: '✓',
      label: 'IN REGULATIONS',
    },
    'Watch Zone': {
      bg: 'bg-yellow-500/10 border-yellow-500/30',
      text: 'text-yellow-400',
      icon: '⚡',
      label: 'WATCH ZONE',
    },
    'Out of Regs': {
      bg: 'bg-red-500/10 border-red-500/30',
      text: 'text-red-400',
      icon: '✗',
      label: 'OUT OF REGULATIONS',
    },
  };
  return configs[riskLevel];
}

export default function ResultSection({
  result,
  pftScore,
  cftScore,
  onReset,
}: ResultSectionProps) {
  const riskAccent = getRiskAccent(result.riskLevel);
  const banner = getRiskBanner(result.riskLevel);

  return (
    <div id="results" className="mt-10 pt-8 border-t border-[#1e3a24] space-y-6">
      {/* Section header */}
      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-[#1e3a24]" />
        <span className="text-[10px] font-mono tracking-[0.3em] text-[#4ade80]/50 uppercase">
          Assessment Results
        </span>
        <div className="h-px flex-1 bg-[#1e3a24]" />
      </div>

      {/* STATUS BANNER */}
      <div className={`border ${banner.bg} p-5 flex items-center gap-4`}>
        <div
          className={`text-3xl font-mono font-bold ${banner.text} w-10 text-center shrink-0`}
        >
          {banner.icon}
        </div>
        <div>
          <p className={`text-xs font-mono tracking-[0.25em] ${banner.text} opacity-70 uppercase`}>
            Status
          </p>
          <p className={`text-xl font-mono font-bold ${banner.text} tracking-wider`}>
            {banner.label}
          </p>
        </div>
        <div className="ml-auto">
          <span
            className={`text-xs font-mono border px-2 py-1 ${
              result.passFailStatus === 'PASS'
                ? 'border-[#4ade80]/40 text-[#4ade80]'
                : 'border-red-500/40 text-red-400'
            }`}
          >
            {result.passFailStatus}
          </span>
        </div>
      </div>

      {/* PLAIN ENGLISH MESSAGE */}
      <div className="bg-[#0a0f0d] border border-[#1e3a24] p-4">
        <p className="text-xs font-mono tracking-widest text-[#4ade80]/60 uppercase mb-2">
          Assessment Summary
        </p>
        <p className="text-sm text-[#a3c4a8] font-mono leading-relaxed">
          {result.message}
        </p>
      </div>

      {/* KEY METRICS GRID */}
      <div className="grid grid-cols-2 gap-3">
        <ResultCard
          label="Body Weight"
          value={result.currentWeight}
          unit="lbs"
          accent="neutral"
        />
        <ResultCard
          label="Max Allowed"
          value={result.maxAllowableWeight}
          unit="lbs"
          accent="neutral"
        />
        <ResultCard
          label="Body Fat Est."
          value={`${result.estimatedBodyFat}%`}
          accent={
            result.estimatedBodyFat > result.maxBodyFat ? 'red' : riskAccent
          }
        />
        <ResultCard
          label="BF Limit"
          value={`${result.maxBodyFat}%`}
          accent="neutral"
        />
      </div>

      {/* FITNESS SCORES */}
      <div className="grid grid-cols-2 gap-3">
        <ResultCard
          label="PFT Score"
          value={pftScore}
          unit="/ 300"
          accent={pftScore >= 225 ? 'green' : pftScore >= 150 ? 'yellow' : 'red'}
        />
        <ResultCard
          label="CFT Score"
          value={cftScore}
          unit="/ 300"
          accent={cftScore >= 225 ? 'green' : cftScore >= 150 ? 'yellow' : 'red'}
        />
      </div>

      {/* RECOMMENDATIONS (only if out of regs or watch zone) */}
      {(result.poundsToLose !== null || result.waistToLose !== null) && (
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="h-px flex-1 bg-[#1e3a24]" />
            <span className="text-[10px] font-mono tracking-[0.3em] text-[#4ade80]/50 uppercase">
              Recommendations
            </span>
            <div className="h-px flex-1 bg-[#1e3a24]" />
          </div>

          {result.poundsToLose !== null && (
            <div className="bg-[#0a0f0d] border border-red-500/20 p-4 flex items-start gap-3">
              <span className="text-red-400 font-mono text-lg shrink-0">↓</span>
              <div>
                <p className="text-xs font-mono tracking-widest text-red-400/70 uppercase mb-1">
                  Weight Reduction Needed
                </p>
                <p className="text-red-400 font-mono font-bold text-xl">
                  {result.poundsToLose} lbs
                </p>
                <p className="text-xs text-[#a3c4a8]/60 font-mono mt-1">
                  Estimated to reach the height/weight standard
                </p>
              </div>
            </div>
          )}

          {result.waistToLose !== null && (
            <div className="bg-[#0a0f0d] border border-red-500/20 p-4 flex items-start gap-3">
              <span className="text-red-400 font-mono text-lg shrink-0">↓</span>
              <div>
                <p className="text-xs font-mono tracking-widest text-red-400/70 uppercase mb-1">
                  Waist Reduction Needed
                </p>
                <p className="text-red-400 font-mono font-bold text-xl">
                  ~{result.waistToLose} in
                </p>
                <p className="text-xs text-[#a3c4a8]/60 font-mono mt-1">
                  Estimated to reach body fat standard via tape method
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* DISCLAIMER */}
      <div className="bg-yellow-500/5 border border-yellow-500/20 p-4">
        <p className="text-[10px] font-mono text-yellow-400/60 leading-relaxed">
          ⚠ These results are estimates based on the DoD circumference (tape) method
          and published MCO 6100.13A height/weight tables. They are not a substitute
          for an official USMC weigh-in. Always verify your status against current
          governing orders and your unit&apos;s official weigh-in procedures.
        </p>
      </div>

      {/* RESET BUTTON */}
      <button
        onClick={onReset}
        className="w-full border border-[#1e3a24] text-[#4ade80]/60 font-mono text-sm tracking-widest uppercase py-3 hover:border-[#4ade80]/40 hover:text-[#4ade80] transition-colors"
      >
        ← New Assessment
      </button>
    </div>
  );
}
