export interface ValidationErrors {
  sex?: string;
  age?: string;
  heightInches?: string;
  weightLbs?: string;
  neckInches?: string;
  waistInches?: string;
  hipInches?: string;
  pftScore?: string;
  cftScore?: string;
}

export interface FormData {
  sex: string;
  age: string;
  heightInches: string;
  weightLbs: string;
  neckInches: string;
  waistInches: string;
  hipInches: string; // required for females; ignored for males
  pftScore: string;
  cftScore: string;
}

export function validateInputs(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  if (!data.sex) errors.sex = 'Please select a sex.';

  const age = Number(data.age);
  if (!data.age || isNaN(age) || age < 17 || age > 65)
    errors.age = 'Age must be between 17 and 65.';

  const height = Number(data.heightInches);
  if (!data.heightInches || isNaN(height) || height < 50 || height > 90)
    errors.heightInches = 'Height must be between 50 and 90 inches.';

  const weight = Number(data.weightLbs);
  if (!data.weightLbs || isNaN(weight) || weight < 80 || weight > 350)
    errors.weightLbs = 'Weight must be between 80 and 350 lbs.';

  const neck = Number(data.neckInches);
  if (!data.neckInches || isNaN(neck) || neck < 8 || neck > 30)
    errors.neckInches = 'Neck must be between 8 and 30 inches.';

  const waist = Number(data.waistInches);
  if (!data.waistInches || isNaN(waist) || waist < 20 || waist > 70)
    errors.waistInches = 'Waist must be between 20 and 70 inches.';

  if (waist <= neck && !errors.waistInches && !errors.neckInches)
    errors.waistInches = 'Waist must be greater than neck measurement.';

  // Hip is required for females (official DoD tape method needs it)
  if (data.sex === 'female') {
    const hip = Number(data.hipInches);
    if (!data.hipInches || isNaN(hip) || hip < 20 || hip > 80)
      errors.hipInches = 'Hip must be between 20 and 80 inches.';
    else if (hip < waist && !errors.waistInches)
      errors.hipInches = 'Hip should generally be equal to or larger than waist.';
  }

  const pft = Number(data.pftScore);
  if (!data.pftScore || isNaN(pft) || pft < 0 || pft > 300)
    errors.pftScore = 'PFT score must be between 0 and 300.';

  const cft = Number(data.cftScore);
  if (!data.cftScore || isNaN(cft) || cft < 0 || cft > 300)
    errors.cftScore = 'CFT score must be between 0 and 300.';

  return errors;
}
