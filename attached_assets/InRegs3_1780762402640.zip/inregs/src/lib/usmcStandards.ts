/**
 * =============================================================================
 * usmcStandards.ts — USMC Height/Weight & Body Composition Standards
 * =============================================================================
 *
 * SOURCE: MCO 6100.13A W/CH 3 (Marine Corps Body Composition and
 *         Military Appearance Program), effective 01 Jul 2023.
 *
 * This file is the SINGLE SOURCE OF TRUTH for all numeric standards.
 * The calculator logic in marineStandards.ts imports from here.
 *
 * HOW TO UPDATE:
 *   When a new MCO is issued, update the values in this file only.
 *   No other file needs to change.
 *
 * SECTIONS:
 *   1. Types
 *   2. Height/Weight Tables (MCO Table 6-1)
 *   3. Body Fat Standards by Age/Sex (MCO Table 6-2)
 *   4. DoD Circumference (Tape) Method Formulas
 *   5. Watch Zone Thresholds
 *   6. Fitness Score Thresholds
 *   7. Accessor Functions
 * =============================================================================
 */

export type Sex = 'male' | 'female';

// =============================================================================
// 1. HEIGHT/WEIGHT TABLES
//    Source: MCO 6100.13A W/CH 3, Table 6-1
//    Maximum allowable weight (lbs) by height (inches).
//    Heights below 58" or above 80" are handled by clamping to nearest entry.
// =============================================================================

export const MALE_MAX_WEIGHT_TABLE: Record<number, number> = {
  58: 131,
  59: 133,
  60: 136,
  61: 139,
  62: 141,
  63: 144,
  64: 148,
  65: 150,
  66: 153,
  67: 156,
  68: 160,
  69: 163,
  70: 166,
  71: 170,
  72: 173,
  73: 176,
  74: 180,
  75: 183,
  76: 186,
  77: 190,
  78: 193,
  79: 196,
  80: 200,
};

export const FEMALE_MAX_WEIGHT_TABLE: Record<number, number> = {
  58: 119,
  59: 121,
  60: 124,
  61: 127,
  62: 130,
  63: 133,
  64: 137,
  65: 139,
  66: 142,
  67: 145,
  68: 148,
  69: 152,
  70: 155,
  71: 158,
  72: 161,
  73: 164,
  74: 168,
  75: 171,
  76: 174,
  77: 177,
  78: 180,
  79: 183,
  80: 186,
};

// =============================================================================
// 2. BODY FAT STANDARDS BY AGE GROUP
//    Source: MCO 6100.13A W/CH 3, Table 6-2
//    Maximum allowable body fat percentage by sex and age bracket.
//
//    Age bracket key: age <= the number shown.
//    The last entry is the catch-all for all ages above the highest bracket.
//
//    Male:
//      17–25  → 18%
//      26–30  → 19%
//      31–35  → 20%
//      36–40  → 21%
//      41+    → 22%
//
//    Female:
//      17–25  → 26%
//      26–30  → 27%
//      31–35  → 28%
//      36–40  → 29%
//      41+    → 30%
// =============================================================================

export interface BFBracket {
  /** Upper bound of age bracket (inclusive). Use Infinity for the final bracket. */
  maxAge: number;
  /** Maximum allowable body fat percentage for this bracket. */
  maxBF: number;
}

export const MALE_BF_STANDARDS: BFBracket[] = [
  { maxAge: 25, maxBF: 18 },
  { maxAge: 30, maxBF: 19 },
  { maxAge: 35, maxBF: 20 },
  { maxAge: 40, maxBF: 21 },
  { maxAge: Infinity, maxBF: 22 },
];

export const FEMALE_BF_STANDARDS: BFBracket[] = [
  { maxAge: 25, maxBF: 26 },
  { maxAge: 30, maxBF: 27 },
  { maxAge: 35, maxBF: 28 },
  { maxAge: 40, maxBF: 29 },
  { maxAge: Infinity, maxBF: 30 },
];

// =============================================================================
// 3. DoD CIRCUMFERENCE (TAPE METHOD) FORMULA COEFFICIENTS
//    Source: DoD Instruction 1308.3, Enclosure 3; used by USMC per MCO 6100.13A
//
//    MALE formula:
//      %BF = (86.010 × log10(abdomen − neck)) − (70.041 × log10(height)) + 36.76
//
//    FEMALE formula:
//      %BF = (163.205 × log10(waist + hip − neck)) − (97.684 × log10(height)) − 78.387
//
//    ⚠️  FEMALE NOTE: The official formula requires a hip circumference
//    measurement (measured at the widest point). The current UI does not
//    collect hip — add a "Hip (in)" input field and pass it through to
//    `estimateBodyFat()` to use the official formula.
//    The fallback below uses waist × HIP_FALLBACK_MULTIPLIER as an approximation
//    until hip input is available.
// =============================================================================

export const TAPE_METHOD = {
  male: {
    // %BF = A × log10(abdomen − neck) − B × log10(height) + C
    A: 86.010,
    B: 70.041,
    C: 36.76,
  },
  female: {
    // %BF = A × log10(waist + hip − neck) − B × log10(height) − C
    A: 163.205,
    B: 97.684,
    C: 78.387,
    /** Multiplier applied to waist to approximate hip when hip is not measured.
     *  Replace with actual hip input when the field is added to the UI. */
    HIP_FALLBACK_MULTIPLIER: 1.15,
  },
} as const;

// =============================================================================
// 4. WATCH ZONE THRESHOLDS
//    These are app-defined (not from the MCO) and control when the UI
//    shows "Watch Zone" instead of "In Regs."
//    Adjust to taste — they do not affect pass/fail determination.
// =============================================================================

export const WATCH_ZONE = {
  /** Show Watch Zone if within this many lbs of the max weight limit. */
  WEIGHT_LBS: 10,
  /** Show Watch Zone if within this many body fat percentage points of the limit. */
  BODY_FAT_PCT: 3,
} as const;

// =============================================================================
// 5. FITNESS SCORE THRESHOLDS
//    Source: MCO 6100.13A / MARADMIN 412/19 and subsequent updates.
//    Used only for UI color coding in ResultCard — not a pass/fail gate
//    in the body composition calculator (BCP is separate from PFT/CFT).
//
//    First-class:  285–300
//    Second-class: 225–284
//    Third-class:  150–224  (minimum passing)
//    Failure:      < 150
// =============================================================================

export const FITNESS_SCORE_THRESHOLDS = {
  FIRST_CLASS: 285,
  SECOND_CLASS: 225,
  THIRD_CLASS: 150, // minimum passing score
} as const;

// =============================================================================
// 6. HEIGHT CLAMP RANGE
//    Heights outside the official table range are clamped to nearest entry.
// =============================================================================

export const HEIGHT_RANGE = {
  MIN_INCHES: 58,
  MAX_INCHES: 80,
} as const;

// =============================================================================
// 7. ACCESSOR FUNCTIONS
//    Clean interfaces used by marineStandards.ts — isolates table lookups
//    from calculator logic.
// =============================================================================

/**
 * Returns the maximum allowable weight (lbs) for a given sex and height.
 * Heights outside the table range are clamped to the nearest entry.
 */
export function getMaxAllowableWeight(sex: Sex, heightInches: number): number {
  const table =
    sex === 'male' ? MALE_MAX_WEIGHT_TABLE : FEMALE_MAX_WEIGHT_TABLE;
  const h = Math.round(
    Math.min(HEIGHT_RANGE.MAX_INCHES, Math.max(HEIGHT_RANGE.MIN_INCHES, heightInches))
  );
  return table[h] ?? (sex === 'male' ? MALE_MAX_WEIGHT_TABLE[80] : FEMALE_MAX_WEIGHT_TABLE[80]);
}

/**
 * Returns the maximum allowable body fat percentage for a given sex and age.
 */
export function getMaxAllowableBodyFat(sex: Sex, age: number): number {
  const brackets = sex === 'male' ? MALE_BF_STANDARDS : FEMALE_BF_STANDARDS;
  const bracket = brackets.find((b) => age <= b.maxAge);
  // Fallback to last bracket (should never happen with Infinity sentinel)
  return bracket?.maxBF ?? brackets[brackets.length - 1].maxBF;
}

/**
 * Estimates body fat percentage using the DoD circumference (tape) method.
 *
 * @param sex           - 'male' or 'female'
 * @param heightInches  - Standing height in inches
 * @param neckInches    - Neck circumference in inches (measured below larynx)
 * @param waistInches   - Abdomen/waist circumference in inches (at navel for males)
 * @param hipInches     - Hip circumference in inches (females only, widest point).
 *                        If omitted, a fallback approximation is used.
 *
 * @returns Estimated body fat percentage, rounded to one decimal place.
 */
export function estimateBodyFatPct(
  sex: Sex,
  heightInches: number,
  neckInches: number,
  waistInches: number,
  hipInches?: number
): number {
  if (sex === 'male') {
    const { A, B, C } = TAPE_METHOD.male;
    const diff = waistInches - neckInches;
    if (diff <= 0) return 0; // guard against log of non-positive
    const bf = A * Math.log10(diff) - B * Math.log10(heightInches) + C;
    return Math.max(0, Math.round(bf * 10) / 10);
  } else {
    const { A, B, C, HIP_FALLBACK_MULTIPLIER } = TAPE_METHOD.female;
    const hip = hipInches ?? waistInches * HIP_FALLBACK_MULTIPLIER;
    const sum = waistInches + hip - neckInches;
    if (sum <= 0) return 0;
    const bf = A * Math.log10(sum) - B * Math.log10(heightInches) - C;
    return Math.max(0, Math.round(bf * 10) / 10);
  }
}

/**
 * Returns a PFT/CFT performance label for UI display.
 */
export function fitnessScoreLabel(
  score: number
): 'First Class' | 'Second Class' | 'Third Class' | 'Failure' {
  if (score >= FITNESS_SCORE_THRESHOLDS.FIRST_CLASS) return 'First Class';
  if (score >= FITNESS_SCORE_THRESHOLDS.SECOND_CLASS) return 'Second Class';
  if (score >= FITNESS_SCORE_THRESHOLDS.THIRD_CLASS) return 'Third Class';
  return 'Failure';
}
