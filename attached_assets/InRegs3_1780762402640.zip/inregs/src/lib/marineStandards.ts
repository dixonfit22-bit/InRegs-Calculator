/**
 * marineStandards.ts — Calculator Engine
 *
 * This file contains ONLY calculation logic — no raw standards data.
 * All numeric thresholds, tables, and formulas live in usmcStandards.ts.
 *
 * To update standards when a new MCO is issued: edit usmcStandards.ts only.
 */

import {
  Sex,
  getMaxAllowableWeight,
  getMaxAllowableBodyFat,
  estimateBodyFatPct,
  WATCH_ZONE,
} from './usmcStandards';

// Re-export Sex so existing imports from marineStandards.ts keep working
export type { Sex };

export interface MarineInput {
  sex: Sex;
  age: number;
  heightInches: number;
  weightLbs: number;
  neckInches: number;
  waistInches: number;
  hipInches?: number; // required for females; optional until field was added
  pftScore: number;
  cftScore: number;
}

export interface RegResult {
  currentWeight: number;
  estimatedBodyFat: number;
  passFailStatus: 'PASS' | 'FAIL';
  riskLevel: 'In Regs' | 'Watch Zone' | 'Out of Regs';
  message: string;
  poundsToLose: number | null;
  waistToLose: number | null;
  maxAllowableWeight: number;
  maxBodyFat: number;
  overWeightLimit: boolean;
  tapeRequired: boolean;
}

// ---------------------------------------------------------------------------
// WAIST-REDUCTION ESTIMATE
// Rough approximation: each 1% BF above the limit ≈ 0.9 inches of waist
// via the tape method. Not medically precise — for guidance only.
// ---------------------------------------------------------------------------
const WAIST_INCHES_PER_BF_PCT = 0.9;

export function calculateRegStatus(input: MarineInput): RegResult {
  const { sex, age, heightInches, weightLbs, neckInches, waistInches, hipInches } = input;

  // --- Standards lookup (all values come from usmcStandards.ts) ---
  const maxWeight = getMaxAllowableWeight(sex, heightInches);
  const maxBF = getMaxAllowableBodyFat(sex, age);
  const estimatedBF = estimateBodyFatPct(sex, heightInches, neckInches, waistInches, hipInches);

  // --- Pass/Fail ---
  // USMC BCP logic: tape is only administered when a Marine exceeds the
  // height/weight table. They fail ONLY if over the weight table AND over
  // the body fat standard via tape. Over weight but passing tape = PASS.
  const overWeightLimit = weightLbs > maxWeight;
  const overBFLimit = estimatedBF > maxBF;
  const tapeRequired = overWeightLimit;
  const failedTape = tapeRequired && overBFLimit;
  const isFailing = failedTape;

  // --- Reduction estimates ---
  const poundsToLose = overWeightLimit ? Math.ceil(weightLbs - maxWeight) : null;
  const waistToLose = failedTape
    ? Math.ceil((estimatedBF - maxBF) * WAIST_INCHES_PER_BF_PCT)
    : null;

  // --- Watch Zone ---
  const nearWeightLimit = !overWeightLimit && weightLbs >= maxWeight - WATCH_ZONE.WEIGHT_LBS;
  const nearBFLimit = !overBFLimit && estimatedBF >= maxBF - WATCH_ZONE.BODY_FAT_PCT;
  const isWatchZone = !isFailing && (nearWeightLimit || nearBFLimit);

  const riskLevel: RegResult['riskLevel'] = isFailing
    ? 'Out of Regs'
    : isWatchZone
    ? 'Watch Zone'
    : 'In Regs';

  const passFailStatus: 'PASS' | 'FAIL' = isFailing ? 'FAIL' : 'PASS';

  // --- Plain-English message ---
  let message = '';

  if (riskLevel === 'Out of Regs') {
    message =
      `You are over the weight table limit (${weightLbs} lbs vs. ${maxWeight} lb max) ` +
      `and your estimated body fat of ${estimatedBF}% exceeds the ${maxBF}% limit for your age group. ` +
      `Both conditions must be resolved before your next official weigh-in. See recommendations below. ` +
      `These are estimates only — verify with your unit's official weigh-in procedures.`;
  } else if (riskLevel === 'Watch Zone') {
    const reasons: string[] = [];
    if (nearWeightLimit)
      reasons.push(
        `weight (${weightLbs} lbs — only ${maxWeight - weightLbs} lbs under the ${maxWeight} lb limit)`
      );
    if (nearBFLimit)
      reasons.push(
        `estimated body fat (${estimatedBF}% — only ${(maxBF - estimatedBF).toFixed(1)}% under the ${maxBF}% limit)`
      );
    message =
      `You're in the Watch Zone for your ${reasons.join(' and ')}. ` +
      `You're technically within standards but close to the edge. ` +
      `Now is the time to tighten up before weigh-in. ` +
      `Results are estimates — verify against current USMC guidance.`;
  } else if (overWeightLimit && !failedTape) {
    // Over weight table but passed tape — still a PASS
    message =
      `You are over the height/weight table limit (${weightLbs} lbs vs. ${maxWeight} lb max), ` +
      `but your estimated body fat of ${estimatedBF}% is within the ${maxBF}% standard for your age group. ` +
      `You pass the tape test. Work to get under the weight table before your next weigh-in. ` +
      `These are estimates only — results must be verified against current USMC guidance.`;
  } else {
    message =
      `You're within standards. Your weight of ${weightLbs} lbs is ` +
      `${maxWeight - weightLbs} lbs under the ${maxWeight} lb limit, ` +
      `and your estimated body fat of ${estimatedBF}% is within the ${maxBF}% maximum for your age group. ` +
      `Results are estimates — verify against current USMC guidance.`;
  }

  return {
    currentWeight: weightLbs,
    estimatedBodyFat: estimatedBF,
    passFailStatus,
    riskLevel,
    message,
    poundsToLose,
    waistToLose,
    maxAllowableWeight: maxWeight,
    maxBodyFat: maxBF,
    overWeightLimit,
    tapeRequired,
  };
}
