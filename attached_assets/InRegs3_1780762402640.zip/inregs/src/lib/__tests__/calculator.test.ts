/**
 * calculator.test.ts
 *
 * Unit tests for the InRegs calculator engine.
 * Tests cover the four key outcome states:
 *   1. PASS — fully in regulations
 *   2. PASS — Watch Zone (near limits but still passing)
 *   3. PASS — over weight table but passes tape (body fat within standard)
 *   4. FAIL — over weight table AND over body fat standard
 *
 * Run with: npm test
 */

import { calculateRegStatus } from '../marineStandards';
import type { MarineInput } from '../marineStandards';

// ---------------------------------------------------------------------------
// Shared base inputs — modify per test case
// ---------------------------------------------------------------------------

const maleBase: MarineInput = {
  sex: 'male',
  age: 25,
  heightInches: 70,   // 5'10" — max weight 166 lbs per table
  weightLbs: 150,
  neckInches: 15,
  waistInches: 32,
  pftScore: 250,
  cftScore: 260,
};

const femaleBase: MarineInput = {
  sex: 'female',
  age: 25,
  heightInches: 65,   // 5'5" — max weight 139 lbs per table
  weightLbs: 128,
  neckInches: 12,
  waistInches: 28,
  hipInches: 36,
  pftScore: 240,
  cftScore: 245,
};

// ---------------------------------------------------------------------------
// TEST 1: Full PASS — under weight table, BF within standard
// ---------------------------------------------------------------------------

describe('Case 1: Full PASS — under weight, BF within standard', () => {
  test('male: 150 lbs at 5\'10" (max 166 lbs) — should PASS', () => {
    const result = calculateRegStatus(maleBase);
    expect(result.passFailStatus).toBe('PASS');
    expect(result.riskLevel).toBe('In Regs');
    expect(result.overWeightLimit).toBe(false);
    expect(result.tapeRequired).toBe(false);
    expect(result.poundsToLose).toBeNull();
    expect(result.waistToLose).toBeNull();
    expect(result.maxAllowableWeight).toBe(166);
    expect(result.estimatedBodyFat).toBeGreaterThan(0);
    expect(result.estimatedBodyFat).toBeLessThanOrEqual(result.maxBodyFat);
  });

  test('female: 128 lbs at 5\'5" (max 139 lbs) — should PASS', () => {
    const result = calculateRegStatus(femaleBase);
    expect(result.passFailStatus).toBe('PASS');
    expect(result.riskLevel).toBe('In Regs');
    expect(result.overWeightLimit).toBe(false);
    expect(result.tapeRequired).toBe(false);
    expect(result.poundsToLose).toBeNull();
    expect(result.waistToLose).toBeNull();
  });

  test('message contains estimate disclaimer', () => {
    const result = calculateRegStatus(maleBase);
    expect(result.message.toLowerCase()).toContain('estimate');
  });
});

// ---------------------------------------------------------------------------
// TEST 2: Watch Zone — near limits but still PASS
// ---------------------------------------------------------------------------

describe('Case 2: Watch Zone — close to limits, still PASS', () => {
  test('male: 158 lbs at 5\'10" (max 166 lbs) — within 10 lbs, Watch Zone', () => {
    const result = calculateRegStatus({ ...maleBase, weightLbs: 158 });
    expect(result.passFailStatus).toBe('PASS');
    expect(result.riskLevel).toBe('Watch Zone');
    expect(result.overWeightLimit).toBe(false);
    expect(result.tapeRequired).toBe(false);
    expect(result.poundsToLose).toBeNull();
  });

  test('male: near BF limit — Watch Zone', () => {
    // Push waist up to approach BF limit (18% for age <=25)
    // At 70" height, 15" neck, waist ~36 should push BF close to 18%
    const result = calculateRegStatus({ ...maleBase, weightLbs: 155, waistInches: 35.5 });
    expect(result.passFailStatus).toBe('PASS');
    // May be Watch Zone or In Regs depending on exact BF estimate
    expect(['In Regs', 'Watch Zone']).toContain(result.riskLevel);
  });

  test('watch zone message contains "Watch Zone"', () => {
    const result = calculateRegStatus({ ...maleBase, weightLbs: 158 });
    expect(result.message).toContain('Watch Zone');
  });
});

// ---------------------------------------------------------------------------
// TEST 3: Overweight but PASSES tape — still a PASS
// ---------------------------------------------------------------------------

describe('Case 3: Over weight table but passes tape (PASS)', () => {
  test('male: 170 lbs at 5\'10" (4 lbs over 166 lb limit) — tape required', () => {
    // 170 lbs > 166 lb max, so tape is administered.
    // With a tight waist (30") and large neck (17"), BF estimate should be low.
    const result = calculateRegStatus({
      ...maleBase,
      weightLbs: 170,
      neckInches: 17,
      waistInches: 30,
    });
    expect(result.overWeightLimit).toBe(true);
    expect(result.tapeRequired).toBe(true);
    expect(result.passFailStatus).toBe('PASS');
    expect(result.riskLevel).toBe('In Regs');
    expect(result.poundsToLose).toBe(4); // 170 - 166
    expect(result.waistToLose).toBeNull(); // passed tape, no waist reduction needed
    expect(result.estimatedBodyFat).toBeLessThanOrEqual(result.maxBodyFat);
  });

  test('overweight-passes-tape message mentions weight table and passing tape', () => {
    const result = calculateRegStatus({
      ...maleBase,
      weightLbs: 170,
      neckInches: 17,
      waistInches: 30,
    });
    expect(result.message.toLowerCase()).toContain('weight table limit');
    expect(result.message.toLowerCase()).toContain('pass');
  });
});

// ---------------------------------------------------------------------------
// TEST 4: FAIL — over weight AND over BF standard
// ---------------------------------------------------------------------------

describe('Case 4: FAIL — over weight table AND over body fat standard', () => {
  test('male: 185 lbs at 5\'10" with large waist — should FAIL', () => {
    // 185 lbs > 166 lb max → tape required.
    // With wide waist and small neck, BF will exceed 18% limit for age <=25.
    const result = calculateRegStatus({
      ...maleBase,
      weightLbs: 185,
      neckInches: 14,
      waistInches: 42,
    });
    expect(result.overWeightLimit).toBe(true);
    expect(result.tapeRequired).toBe(true);
    expect(result.passFailStatus).toBe('FAIL');
    expect(result.riskLevel).toBe('Out of Regs');
    expect(result.poundsToLose).toBe(19); // 185 - 166
    expect(result.waistToLose).not.toBeNull();
    expect(result.estimatedBodyFat).toBeGreaterThan(result.maxBodyFat);
  });

  test('fail message contains "out of regulations" language', () => {
    const result = calculateRegStatus({
      ...maleBase,
      weightLbs: 185,
      neckInches: 14,
      waistInches: 42,
    });
    expect(result.message.toLowerCase()).toContain('over the weight table limit');
  });

  test('female: fail case', () => {
    const result = calculateRegStatus({
      ...femaleBase,
      weightLbs: 155, // over 139 lb max
      neckInches: 11,
      waistInches: 38,
      hipInches: 44,
    });
    expect(result.overWeightLimit).toBe(true);
    expect(result.tapeRequired).toBe(true);
    // BF result depends on formula; just confirm structure is correct
    expect(['PASS', 'FAIL']).toContain(result.passFailStatus);
    expect(result.poundsToLose).toBe(16); // 155 - 139
  });
});

// ---------------------------------------------------------------------------
// Edge cases
// ---------------------------------------------------------------------------

describe('Edge cases', () => {
  test('exactly at weight limit — not over, no tape required', () => {
    const result = calculateRegStatus({ ...maleBase, weightLbs: 166 });
    expect(result.overWeightLimit).toBe(false);
    expect(result.tapeRequired).toBe(false);
    expect(result.passFailStatus).toBe('PASS');
  });

  test('one pound over limit — tape required', () => {
    const result = calculateRegStatus({ ...maleBase, weightLbs: 167 });
    expect(result.overWeightLimit).toBe(true);
    expect(result.tapeRequired).toBe(true);
    expect(result.poundsToLose).toBe(1);
  });

  test('result always includes maxAllowableWeight and maxBodyFat', () => {
    const result = calculateRegStatus(maleBase);
    expect(result.maxAllowableWeight).toBeGreaterThan(0);
    expect(result.maxBodyFat).toBeGreaterThan(0);
  });

  test('estimated body fat is always a positive number', () => {
    const result = calculateRegStatus(maleBase);
    expect(result.estimatedBodyFat).toBeGreaterThan(0);
  });
});
