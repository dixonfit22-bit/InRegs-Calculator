/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'marine-green': '#4ade80',
        'marine-green-dark': '#16a34a',
        'marine-green-dim': '#166534',
        'bg-dark': '#0a0f0d',
        'bg-card': '#111a14',
        'bg-card-alt': '#0f1a12',
        'border-dim': '#1e3a24',
      },
      fontFamily: {
        display: ['var(--font-display)', 'monospace'],
        body: ['var(--font-body)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
    },
  },
  plugins: [],
}
