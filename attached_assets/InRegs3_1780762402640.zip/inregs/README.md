# InRegs

**Know where you stand before weigh-in.**

InRegs is a mobile-first web app that helps Marines quickly estimate whether they are within USMC height/weight and body composition standards. It uses the DoD circumference (tape) method formula and the published MCO 6100.13A height/weight tables.

> ⚠️ **Results are estimates only.** This tool is not a substitute for an official USMC weigh-in. Always verify your status against the current governing order (MCO 6100.13A) and your unit's official weigh-in procedures.

---

## Tech Stack

- [Next.js 14](https://nextjs.org/) (App Router)
- [React 18](https://react.dev/)
- [TypeScript](https://www.typescriptlang.org/)
- [Tailwind CSS](https://tailwindcss.com/)

---

## Project Structure

```
inregs/
├── README.md
├── package.json
├── next.config.js
├── tsconfig.json
├── tailwind.config.js
├── postcss.config.js
└── src/
    ├── app/
    │   ├── layout.tsx           # Root layout, fonts, metadata
    │   ├── globals.css          # Tailwind base + custom animations
    │   ├── page.tsx             # Landing page
    │   └── calculator/
    │       └── page.tsx         # Calculator page
    ├── components/
    │   ├── Header.tsx           # Sticky nav
    │   ├── InputField.tsx       # Reusable number input
    │   ├── SelectField.tsx      # Reusable dropdown
    │   ├── ResultCard.tsx       # Metric display tile
    │   ├── CalculatorForm.tsx   # Full form + submit logic
    │   └── ResultSection.tsx    # Results panel
    └── lib/
        ├── usmcStandards.ts     # ← All numeric standards (edit this to update)
        ├── marineStandards.ts   # Calculator engine (imports from usmcStandards)
        ├── validation.ts        # Input validation
        └── __tests__/
            └── calculator.test.ts  # Unit tests
```

---

## Prerequisites

- **Node.js** 18.17 or later
- **npm** 9 or later (bundled with Node)

Check your versions:

```bash
node -v
npm -v
```

---

## Install

```bash
# Clone or unzip the project, then:
cd inregs
npm install
```

---

## Run (Development)

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser. The app hot-reloads on save.

---

## Build (Production)

```bash
npm run build
```

This generates an optimized production build in `.next/`. Check for any TypeScript or lint errors in the output.

To run the production build locally:

```bash
npm run start
```

---

## Test

```bash
npm test
```

Test cases cover:
- Full pass (under weight, under BF limit)
- Watch zone (near weight limit)
- Overweight but passes tape (PASS)
- Fail (over weight AND over BF)

---

## Deploy

### Vercel (recommended — zero config)

1. Push the project to a GitHub, GitLab, or Bitbucket repo.
2. Go to [vercel.com](https://vercel.com) and import the repo.
3. Vercel auto-detects Next.js. Click **Deploy**.
4. Your app is live at `https://your-project.vercel.app`.

No environment variables are required for the base app (no database, no auth).

### Netlify

1. Run `npm run build` locally.
2. Drag and drop the `.next/` folder into [app.netlify.com/drop](https://app.netlify.com/drop), **or**
3. Connect your repo and set the build command to `npm run build` and publish directory to `.next`.

> Note: Netlify requires the `@netlify/plugin-nextjs` plugin for full App Router support. Add it via the Netlify UI or `netlify.toml`.

### Self-hosted (Node server)

```bash
npm run build
npm run start        # runs on port 3000 by default
```

To run on a different port:

```bash
PORT=8080 npm run start
```

Use a reverse proxy (nginx, Caddy) in front of Node for production.

### Docker

```dockerfile
FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/public ./public
COPY --from=builder /app/package*.json ./
RUN npm ci --omit=dev
EXPOSE 3000
CMD ["npm", "run", "start"]
```

```bash
docker build -t inregs .
docker run -p 3000:3000 inregs
```

---

## Updating Standards

All numeric standards live in one file: **`src/lib/usmcStandards.ts`**

When a new MCO is issued:

1. Open `src/lib/usmcStandards.ts`
2. Update the relevant tables/values (each section is clearly labelled with its MCO source)
3. Run `npm test` to verify the calculator still behaves correctly
4. Run `npm run build` to confirm no TypeScript errors
5. Deploy

No other files need to change.

---

## Known Limitations

- **Female hip measurement**: The official DoD tape formula for females requires a hip circumference (widest point). The hip input field is now included in the form and wired through to the formula.
- **No official audit**: This tool has not been reviewed or certified by USMC or DoD. Use for personal estimation only.
- **Rounding**: Results are rounded to one decimal place for body fat and to the nearest whole number for weight.

---

## License

Private. Not for redistribution.
